package com.si.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sreeja1Application {

	public static void main(String[] args) {
		SpringApplication.run(Sreeja1Application.class, args);
	}

}
