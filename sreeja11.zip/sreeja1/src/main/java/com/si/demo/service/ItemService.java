package com.si.demo.service;

import java.util.List;

import com.si.demo.entity.Item;

public interface ItemService {

	Item save(Item item);

	List<Item> fetchItemList();

	Item fetchItemById(Long itemId);

	void deleteItemById(Long itemId);

	Item updateItem(Long itemId, Item item);

}
